<?php 
define('HOST', 'localhost');
define('USER', 'lpg');
define('PASS', 'admin');
define('DATABASE', 'lpgenerator');