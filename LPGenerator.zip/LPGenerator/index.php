<?php
include 'header.php';

// myvardump($tmpl_1);


include_form($tmpl_common_css);

include_files('templates/html/html-output/sections');



echo '<pre>';
var_dump($GLOBALS);
echo '</pre>';
echo '<pre>';
echo '<pre>';
echo '<pre>';














include 'footer.php';