	<!--          *****************   javascript   ***************                    -->

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> -->
    <script src="assets/js/jquery-1.12.3.min.js"></script>
    <!-- slider JS -->
    <script type="text/javascript" src="assets/plugins/flexslider/jquery.flexslider-min.js"></script>
    <!-- popup JS -->
    <script src="assets/plugins/magnific-popup/jquery.magnific-popup.min.js"></script>
    <!-- ssi-uploader.js -->
    <!-- <script src="assets/plugins/dropzone/dropzone.js"></script> -->
    <!-- custom js -->
    <script type="text/javascript" src="assets/js/custom.js"></script>
    <!-- initializations -->
    <script type="text/javascript" src="assets/js/init.js"></script>
    <!-- admin.js -->
    <script type="text/javascript" src="assets/js/admin.js"></script>

</body>
</html>