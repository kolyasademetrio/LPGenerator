<div class="title_text_center">
	<label>Положение заголовка блока
		<select name="title_text_center">
			<option value="">Выбрать</option>
			<option value="text-center">По центру</option>
			<option value="text-left">Слева</option>
			<option value="text-right">Справа</option>
		</select>
	</label>
</div>