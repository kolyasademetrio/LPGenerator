<div class="title_text_uppercase">
  <label>Заглавные/прописные буквы заголовка блока
  		<select name="title_text_uppercase">
  			<option value="">Выбрать</option>
  			<option value="text-uppercase">Все большие</option>
  			<option value="text-capitalize">Первая большая</option>
  			<option value="text-lowercase">Все маленькие</option>
			</select>
  </label>
</div><!-- .title_text_uppercase -->