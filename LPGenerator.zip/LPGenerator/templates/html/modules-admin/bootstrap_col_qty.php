<div class="bootstrap_col_qty">
	<label>Количество блоков: 
		<input type="number" name="count_col" min="1" max="20" value="">		
	</label>
</div><!-- .bootstrap_col_qty -->