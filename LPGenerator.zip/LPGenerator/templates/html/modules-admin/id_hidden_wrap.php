<div class="id_hidden_wrap">
	<input name="id" hidden="hidden" value="<?php echo ${$global_arr}['id']; ?>">
</div><!-- .id_hidden_wrap -->