<div class="section_name_hidden_wrap">
	<input name="sect_name" hidden="hidden" value="<?php if (isset(${$global_arr}['sect_name'])) echo ${$global_arr}['sect_name']; ?>">
</div><!-- .id_hidden_wrap -->