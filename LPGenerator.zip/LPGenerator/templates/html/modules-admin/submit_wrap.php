<div class="submit_wrap">
	<input type="submit" value="Изменить блок" name="mysubmit">
</div><!-- .submit_wrap -->